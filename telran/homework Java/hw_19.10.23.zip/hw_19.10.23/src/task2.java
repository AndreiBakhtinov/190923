import java.util.Scanner;
/*
Необходимо суммировать все нечётные целые числа в диапазоне,
введённом пользователем. Программу повторять, пока пользователь не введёт «quit».
*/
public class task2 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int sum = 0;
        String cont = "";

        do {
            System.out.println("Enter range(numbers), and I`ll give you sum of all odd numbers in this range.");
            System.out.println("1: ");
            int num1 = scn.nextInt();
            System.out.println("2: ");
            int num2 = scn.nextInt();
            int min = Math.min(num1,num2);
            int max = Math.max(num1,num2);
            for (int i = min; i < max; i++) {
                if (i % 2 != 0){
                    sum += i;
                }
            }
            System.out.println(sum);
            System.out.println("Do you want to try again?(YES/QUIT)");
            cont = scn.nextLine().toLowerCase();
            if (!cont.equals("quit")) sum = 0;
        }while (!cont.equals("quit"));





//        int sum = 0;
//        String cont = "";
//        do {
//            System.out.println("Enter range(number), and I`ll give you sum of all odd numbers in this range.");
//            int userRange1 = new Scanner(System.in).nextInt();
//            int userRange2 = new Scanner(System.in).nextInt();
//            for (int i = userRange1; i < userRange2; i += 2) {
//                sum += i;
//            }
//            System.out.println(sum);
//            System.out.println("Do you want to try again?(YES/QUIT)");
//            cont = new Scanner(System.in).nextLine().toUpperCase();
//            if (!cont.equals("QUIT")) sum = 0;
//        } while (!cont.equals("QUIT"));
    }
}