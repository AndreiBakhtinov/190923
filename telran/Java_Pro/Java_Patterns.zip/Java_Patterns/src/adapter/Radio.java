package adapter;

public class Radio {
    public void listenToMusic(EuroSocket euroSocket) {
        euroSocket.getPower();
    }
}