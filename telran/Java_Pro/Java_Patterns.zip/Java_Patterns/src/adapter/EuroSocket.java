package adapter;

public interface EuroSocket {
    void getPower();
}