package adapter;

public interface AmericanSocket {
    void getPower();
}