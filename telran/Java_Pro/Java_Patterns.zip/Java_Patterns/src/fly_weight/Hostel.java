package fly_weight;

public class Hostel {
}