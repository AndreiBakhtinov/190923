package fly_weight;

public class StudentPersonalInfo {
    String name;
    int age;
    String homeAddress;
    int course;
    double averageMark;
}