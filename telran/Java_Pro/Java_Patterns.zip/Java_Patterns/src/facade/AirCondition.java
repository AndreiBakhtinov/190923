package facade;

public class AirCondition {

    void setTemperature(String temperature) {
        System.out.println("Set temperature " + temperature);
    }
}