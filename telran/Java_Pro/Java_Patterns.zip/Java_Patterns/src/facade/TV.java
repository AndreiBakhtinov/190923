package facade;

public class TV {

    void playChannel(String channel) {
        System.out.println("play channel " + channel);
    }
}