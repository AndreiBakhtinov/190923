package facade;

public class Light {

    void turnLight() {
        System.out.println("Light is on");
    }
}