package abstractFactory;

public class Main {
    public static void main(String[] args) {
        AbstractFactory bmwFactory = new BMWFactory();
        Car car = bmwFactory.getCar();
        Bike bike = bmwFactory.getBike();

        car.drive();
        bike.drive();

        AbstractFactory mercedesFactory = new MercedesFactory();
        Car car1 = mercedesFactory.getCar();
        Bike bike1 = mercedesFactory.getBike();

        car1.drive();
        bike1.drive();
    }
}