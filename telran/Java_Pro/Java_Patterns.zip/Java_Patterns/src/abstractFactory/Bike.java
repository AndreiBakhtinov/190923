package abstractFactory;

public interface Bike {

    void drive();
}