package abstractFactory;

public interface Car {

    void drive();
}