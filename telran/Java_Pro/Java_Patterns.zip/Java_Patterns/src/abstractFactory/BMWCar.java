package abstractFactory;

public class BMWCar implements Car {

    @Override
    public void drive() {
        System.out.println("BMW car");
    }
}