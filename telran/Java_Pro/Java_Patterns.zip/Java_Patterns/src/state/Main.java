package state;

public class Main {
    public static void main(String[] args) {
        GumMachine gumMachine = new GumMachine();
        gumMachine.insert();
        gumMachine.insert();
    }
}