package command;

public class MusicPlayer {

    public void playMusic() {
        System.out.println("Play Music");
    }
}