package command;

public class CoffeeMachine {
    public void makeCoffee() {
        System.out.println("Making coffee");
    }
}
