package command;

public class Phone {

    public void makeCall(String name) {
        System.out.println("Making call " + name);
    }
}