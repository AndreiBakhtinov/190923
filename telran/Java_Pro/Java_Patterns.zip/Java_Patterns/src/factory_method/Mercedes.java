package factory_method;

public class Mercedes implements Car {

    public void drive() {
        System.out.println("Mercedes");
    }
}