package factory_method;

public interface Car {

    void drive();
}