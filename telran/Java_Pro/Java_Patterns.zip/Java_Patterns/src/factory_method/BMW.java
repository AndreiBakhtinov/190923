package factory_method;

public class BMW implements Car {

    public void drive() {
        System.out.println("BMW");
    }
}