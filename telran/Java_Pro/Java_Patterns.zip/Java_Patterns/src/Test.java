public class Test {
    public static void main(String[] args) {
        Integer a1 = 100; Integer b1 =100;
        Integer a31 = 1000; Integer b31 =1000;
        System.out.println(a31 == b31);
        System.out.println(a1 == b1);
        Long a2 = 200L; Long b2 = 200L;
        System.out.println(a2 == b2);
        Boolean a3 = new Boolean("TruE");
        Boolean b3 = new Boolean("Вася");
        System.out.println(a3.equals(b3));
        Double a4 = 10.0; Double b4 = 10.0;
        System.out.println(a4 == b4);
        Character a5 = 'a';
        Character b5 =  97;
        System.out.println(a5 == b5);
    }
}
