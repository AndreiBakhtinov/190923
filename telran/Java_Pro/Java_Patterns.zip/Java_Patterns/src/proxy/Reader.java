package proxy;

public interface Reader {

    String read(String str);
}