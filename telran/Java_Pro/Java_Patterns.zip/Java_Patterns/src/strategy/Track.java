package strategy;

public class Track extends Car{
    public Track(FlyAble flyAble) {
        super(flyAble);
    }
}