package strategy;

public interface FlyAble {
    void fly();
}