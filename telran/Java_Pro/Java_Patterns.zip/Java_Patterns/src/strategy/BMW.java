package strategy;

public class BMW extends Car{
    public BMW(FlyAble flyAble) {
        super(flyAble);
    }
}