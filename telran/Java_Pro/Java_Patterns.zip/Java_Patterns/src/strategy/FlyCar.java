package strategy;

public class FlyCar implements FlyAble{

    @Override
    public void fly() {
        System.out.println("FLY");
    }
}