package decorator;

public interface Pizza {
    String makePizza();
}