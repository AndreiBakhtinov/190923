package observer.version1;

public interface MyObservable {
    void callMe(String msg);
}