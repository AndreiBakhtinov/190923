package brige;

public interface Models {
    void drive(String str);
}