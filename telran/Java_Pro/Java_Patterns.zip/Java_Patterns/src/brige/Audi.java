package brige;

public class Audi implements Models {

    @Override
    public void drive(String str) {
        System.out.println(str + " AUDI");
    }
}