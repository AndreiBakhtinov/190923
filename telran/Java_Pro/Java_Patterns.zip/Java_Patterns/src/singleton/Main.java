package singleton;

public class Main {
}
